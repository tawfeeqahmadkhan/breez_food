'use client';

import { useEffect, useState, useRef } from 'react';

export default function Home() {
  const [restaurant, setRestaurant] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeCategoryId, setActiveCategoryId] = useState(null);
  const categoryRefs = useRef({});

  useEffect(() => {
    const fetchRestaurant = async () => {
      try {
        const res = await fetch(
          'https://api.breez.food/v1/restaurants?idroute=saladandsalad',
          { cache: 'no-store' }
        );

        if (!res.ok) {
          throw new Error('خطا در دریافت اطلاعات رستوران');
        }

        const data = await res.json();
        setRestaurant(data);
      } catch (err) {
        setError(err.message || 'مشکلی پیش آمده است');
      } finally {
        setLoading(false);
      }
    };

    fetchRestaurant();
  }, []);

  const scrollToCategory = (id) => {
    const el = categoryRefs.current[id];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setActiveCategoryId(id);
    }
  };

  if (loading) {
    return (
      <main
        dir="rtl"
        className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900"
      >
        <div className="rounded-3xl border border-white/10 bg-white/5 px-6 py-4 shadow-xl backdrop-blur">
          <p className="text-slate-100 text-sm md:text-base animate-pulse">
            در حال بارگذاری منوی رستوران...
          </p>
        </div>
      </main>
    );
  }

  if (error || !restaurant) {
    return (
      <main
        dir="rtl"
        className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900"
      >
        <div className="max-w-md rounded-3xl border border-red-500/30 bg-red-500/5 px-6 py-5 shadow-2xl backdrop-blur text-center">
          <p className="text-red-400 font-semibold mb-2 text-sm">خطا</p>
          <p className="text-slate-100 text-xs">{error}</p>
        </div>
      </main>
    );
  }


  const theme = restaurant.theme || {};
  const bgColor = theme['Background-color'] || '#FFFFFF';
  const primaryColor = theme['Primary-color'] || '#0f766e';
  const borderColor = theme['Border-color'] || '#E5E7EB';
  const textPrimary = theme['Text-Primary-color'] || '#111827';
  const textSecondary = theme['Text-Secondry-color'] || '#6B7280';
  const selectedColor = theme['Text-Item-Selected-color'] || '#FACC15';

  const allCategories =
    restaurant.menus
      ?.flatMap((m) => m.categories || [])
      .filter((c, index, self) => self.findIndex((x) => x.id === c.id) === index) || [];

  return (
    <main
      dir="rtl"
      className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-slate-100"
    >
      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-5 md:py-8">
        {/* Glass container */}
        <div
          className="rounded-[32px] border shadow-2xl backdrop-blur-xl overflow-hidden"
          style={{ borderColor: borderColor, backgroundColor: bgColor + 'F2' }}
        >
          {/* Top hero */}
          <section className="relative">
            {/* Background Image */}
            <div className="relative h-48 sm:h-60 md:h-72 overflow-hidden">
              <img
                src={restaurant.image}
                alt={restaurant.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-black/10" />
            </div>

            {/* Hero content overlay */}
            <div className="absolute inset-0 flex items-end">
              <div className="w-full px-4 sm:px-6 pb-4 sm:pb-6">
                <div className="flex flex-col md:flex-row-reverse md:items-end md:justify-between gap-3">
                  <div className="space-y-1">
                    <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-white drop-shadow">
                      {restaurant.name}
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-100/90 max-w-xl">
                      {restaurant.description}
                    </p>
                  </div>

                  {/* Rating pill */}
                  <div className="flex items-center gap-2 md:mb-1">
                    <span
                      className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold shadow-md"
                      style={{
                        backgroundColor: `${primaryColor}`,
                        color: '#F9FAFB',
                      }}
                    >
                      <span className="text-base">⭐</span>
                      <span>{restaurant.rate || 0}</span>
                      <span className="opacity-80">/ 5</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Main content */}
          <div className="px-4 sm:px-6 pt-4 pb-6 sm:pb-8 space-y-6 sm:space-y-7">
            {/* Info cards */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4 mt-2">
              {/* Contact */}
              <div
                className="rounded-2xl border bg-white/60 p-4 shadow-sm"
                style={{ borderColor }}
              >
                <p className="text-xs font-semibold mb-2" style={{ color: textPrimary }}>
                  اطلاعات تماس
                </p>
                <div className="space-y-1 text-xs" style={{ color: textSecondary }}>
                  <p className="truncate">{restaurant.call_info?.phone}</p>
                  <p className="truncate">{restaurant.call_info?.email}</p>
                  <p className="text-[11px] mt-1 leading-relaxed">
                    {restaurant.call_info?.address}
                  </p>
                </div>
              </div>

              {/* Time */}
              <div
                className="rounded-2xl border bg-white/60 p-4 shadow-sm"
                style={{ borderColor }}
              >
                <p className="text-xs font-semibold mb-2" style={{ color: textPrimary }}>
                  ساعات کاری امروز
                </p>
                <div className="space-y-1 text-xs" style={{ color: textSecondary }}>
                  {restaurant.working_hours &&
                    Object.entries(restaurant.working_hours).map(([day, t], index) => (
                      <div
                        key={day}
                        className={`flex items-center justify-between text-[11px] ${
                          index !== Object.keys(restaurant.working_hours).length - 1
                            ? 'border-b pb-1'
                            : ''
                        }`}
                        style={{ borderColor: borderColor + '80' }}
                      >
                        <span className="font-medium">{day}</span>
                        <span>
                          {t.open && t.close ? `${t.open} - ${t.close}` : 'بسته'}
                        </span>
                      </div>
                    ))}
                </div>
              </div>

              {/* Language / currency + QR */}
              <div
                className="rounded-2xl border bg-white/60 p-4 shadow-sm flex items-center justify-between gap-3"
                style={{ borderColor }}
              >
                <div className="space-y-1 text-xs" style={{ color: textSecondary }}>
                  <p
                    className="text-xs font-semibold mb-1"
                    style={{ color: textPrimary }}
                  >
                    زبان و واحد پول
                  </p>
                  <p>
                    {restaurant.language?.name} ({restaurant.language?.flag})
                  </p>
                  <p>
                    {restaurant.currency?.name} ({restaurant.currency?.flag})
                  </p>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div
                    className="inline-block rounded-2xl border bg-slate-50 p-2"
                    style={{ borderColor }}
                  >
                    <img
                      src={restaurant.qrcode}
                      alt="QR Code"
                      className="w-16 h-16 object-contain"
                    />
                  </div>
                  <p className="text-[10px]" style={{ color: textSecondary }}>
                    منو در موبایل
                  </p>
                </div>
              </div>
            </section>

            {/* Social + Gallery */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
              {/* Socials */}
              <div
                className="rounded-2xl border bg-white/60 p-4 shadow-sm"
                style={{ borderColor }}
              >
                <p className="text-xs font-semibold mb-2" style={{ color: textPrimary }}>
                  شبکه‌های اجتماعی
                </p>
                <div className="flex flex-wrap gap-2">
                  {restaurant.socials &&
                    Object.entries(restaurant.socials).map(([key, value]) =>
                      value && value !== '#' ? (
                        <a
                          key={key}
                          href={value}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] px-3 py-1 rounded-full border hover:-translate-y-0.5 hover:shadow-sm transition"
                          style={{
                            borderColor,
                            color: primaryColor,
                          }}
                        >
                          {key}
                        </a>
                      ) : (
                        <span
                          key={key}
                          className="text-[11px] px-3 py-1 rounded-full border"
                          style={{
                            borderColor,
                            color: textSecondary,
                          }}
                        >
                          {key}
                        </span>
                      )
                    )}
                </div>
              </div>

              {/* Gallery */}
              <div
                className="md:col-span-2 rounded-2xl border bg-white/60 p-4 shadow-sm"
                style={{ borderColor }}
              >
                <p className="text-xs font-semibold mb-2" style={{ color: textPrimary }}>
                  گالری
                </p>
                {restaurant.gallery ? (
                  <div className="flex gap-3 overflow-x-auto pb-1">
                    {Object.values(restaurant.gallery).map((img, idx) => (
                      <div
                        key={idx}
                        className="min-w-[120px] sm:min-w-[150px] h-24 sm:h-28 rounded-2xl overflow-hidden border bg-slate-100"
                        style={{ borderColor }}
                      >
                        <img
                          src={img}
                          alt={`gallery-${idx}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px]" style={{ color: textSecondary }}>
                    تصویری ثبت نشده است.
                  </p>
                )}
              </div>
            </section>

            {/* Category pills (sticky) */}
            {allCategories.length > 0 && (
              <section className="mt-3">
                <div className="sticky top-3 z-20 -mx-4 sm:-mx-6 px-4 sm:px-6 pt-2 pb-3 bg-gradient-to-b from-[rgba(15,23,42,0.12)] via-[rgba(15,23,42,0.08)] to-transparent backdrop-blur-sm">
                  <div className="flex items-center justify-between mb-2">
                    <h2
                      className="text-sm sm:text-base font-semibold"
                      style={{ color: textPrimary }}
                    >
                      دسته‌بندی‌ها
                    </h2>
                    <span
                      className="text-[10px] px-2 py-0.5 rounded-full border"
                      style={{ borderColor, color: textSecondary }}
                    >
                      برای پرش، روی دسته کلیک کنید
                    </span>
                  </div>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {allCategories.map((cat) => {
                      const isActive = activeCategoryId === cat.id;
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => scrollToCategory(cat.id)}
                          className="whitespace-nowrap rounded-full border px-3 py-1 text-[11px] font-medium transition hover:-translate-y-0.5"
                          style={{
                            borderColor,
                            backgroundColor: isActive
                              ? primaryColor
                              : 'rgba(255,255,255,0.9)',
                            color: isActive ? '#F9FAFB' : textPrimary,
                          }}
                        >
                          {cat.name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </section>
            )}

            {/* Menu section */}
            <section className="space-y-5 sm:space-y-6 mt-2">
              {restaurant.menus?.map((menu) => (
                <div
                  key={menu.id}
                  className="rounded-3xl border bg-white/70 p-4 sm:p-5 md:p-6 shadow-sm"
                  style={{ borderColor }}
                >
                  {/* Menu header */}
                  <div className="flex flex-col md:flex-row-reverse md:items-center md:justify-between gap-3 mb-3">
                    <div>
                      <h3
                        className="text-sm sm:text-base md:text-lg font-semibold"
                        style={{ color: textPrimary }}
                      >
                        {menu.name}
                      </h3>
                      {menu.description && (
                        <p
                          className="text-[11px] sm:text-xs mt-1 whitespace-pre-line leading-relaxed"
                          style={{ color: textSecondary }}
                        >
                          {menu.description}
                        </p>
                      )}
                    </div>
                    {menu.image && (
                      <img
                        src={menu.image}
                        alt={menu.name}
                        className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl object-cover border"
                        style={{ borderColor }}
                      />
                    )}
                  </div>

                  {/* Categories inside menu */}
                  <div className="space-y-5">
                    {menu.categories?.length ? (
                      menu.categories.map((cat) => (
                        <div key={cat.id} ref={(el) => (categoryRefs.current[cat.id] = el)}>
                          {/* Category header */}
                          <div className="flex items-center gap-2 mb-2">
                            {cat.image && (
                              <img
                                src={cat.image}
                                alt={cat.name}
                                className="w-8 h-8 rounded-xl object-cover border bg-slate-50"
                                style={{ borderColor }}
                              />
                            )}
                            <h4
                              className="text-xs sm:text-sm font-semibold"
                              style={{ color: textPrimary }}
                            >
                              {cat.name}
                            </h4>
                          </div>

                          {/* Products grid */}
                          {cat.products?.length ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                              {cat.products.map((p) => {
                                const isSoldOut = p.inventory === 0;
                                const hasDiscount =
                                  p.discounted_price &&
                                  p.discounted_price !== p.regular_price;

                                return (
                                  <div
                                    key={p.id}
                                    className={`relative flex gap-3 rounded-2xl border bg-white/90 p-3 hover:shadow-md hover:-translate-y-0.5 transition ${
                                      isSoldOut ? 'opacity-70' : ''
                                    }`}
                                    style={{ borderColor }}
                                  >
                                    {/* Product image */}
                                    <div className="w-20 h-20 rounded-2xl overflow-hidden bg-slate-100 flex-shrink-0">
                                      <img
                                        src={p.image}
                                        alt={p.name}
                                        className="w-full h-full object-cover"
                                      />
                                    </div>

                                    {/* Content */}
                                    <div className="flex-1 flex flex-col justify-between">
                                      <div>
                                        <div className="flex items-start justify-between gap-2">
                                          <div className="space-y-1">
                                            <p
                                              className="text-xs sm:text-sm font-semibold"
                                              style={{ color: textPrimary }}
                                            >
                                              {p.name}{' '}
                                              {p.emoji && (
                                                <span className="align-middle">
                                                  {p.emoji}
                                                </span>
                                              )}
                                            </p>
                                            {p.description && (
                                              <p
                                                className="text-[11px] leading-snug line-clamp-2"
                                                style={{ color: textSecondary }}
                                              >
                                                {p.description}
                                              </p>
                                            )}
                                          </div>

                                          {p.special && (
                                            <span
                                              className="text-[10px] px-2 py-1 rounded-full font-semibold shadow-sm"
                                              style={{
                                                backgroundColor: selectedColor,
                                                color: '#000',
                                              }}
                                            >
                                              ویژه
                                            </span>
                                          )}
                                        </div>
                                      </div>

                                      {/* Price + inventory */}
                                      <div className="mt-2 flex items-center justify-between text-[11px] sm:text-xs">
                                        <div className="flex items-baseline gap-1">
                                          {hasDiscount ? (
                                            <>
                                              <span
                                                className="font-bold text-sm"
                                                style={{ color: primaryColor }}
                                              >
                                                {p.discounted_price?.toLocaleString()}{' '}
                                                {restaurant.currency?.flag}
                                              </span>
                                              <span className="line-through text-[10px] text-slate-400">
                                                {p.regular_price?.toLocaleString()}
                                              </span>
                                            </>
                                          ) : p.regular_price ? (
                                            <span
                                              className="font-bold text-sm"
                                              style={{ color: primaryColor }}
                                            >
                                              {p.regular_price?.toLocaleString()}{' '}
                                              {restaurant.currency?.flag}
                                            </span>
                                          ) : (
                                            <span style={{ color: textSecondary }}>
                                              قیمت متغیر
                                            </span>
                                          )}
                                        </div>

                                        <div className="flex items-center gap-2">
                                          {p.is_variable && (
                                            <span
                                              className="text-[10px] px-2 py-0.5 rounded-full border"
                                              style={{ borderColor, color: textSecondary }}
                                            >
                                              انتخابی
                                            </span>
                                          )}
                                          <span
                                            className="text-[10px] sm:text-[11px]"
                                            style={{
                                              color: isSoldOut ? '#DC2626' : textSecondary,
                                            }}
                                          >
                                            {isSoldOut
                                              ? 'ناموجود'
                                              : `موجودی: ${p.inventory}`}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <p
                              className="text-[11px] text-center py-3"
                              style={{ color: textSecondary }}
                            >
                              محصولی برای این دسته ثبت نشده است.
                            </p>
                          )}
                        </div>
                      ))
                    ) : (
                      <p
                        className="text-[11px] text-center py-3"
                        style={{ color: textSecondary }}
                      >
                        برای این منو دسته‌بندی ثبت نشده است.
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </section>
          </div>
        </div>
      </div>
    </main>
  );
}
